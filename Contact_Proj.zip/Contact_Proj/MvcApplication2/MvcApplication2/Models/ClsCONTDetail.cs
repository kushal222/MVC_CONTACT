﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.OracleClient;
using MvcApplication2.Models;
using System.Data;

namespace MvcApplication2.Models
{
    public class ClsCONTDetail
    {
        public List<ClsContactInfo> GetContactList()
        {
            List<ClsContactInfo> objlist = new List<ClsContactInfo>();

            string str = ConfigurationManager.ConnectionStrings["staging_ed"].ConnectionString;
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            OracleConnection con = new OracleConnection(str);
            OracleCommand cmd = new OracleCommand("PKG_MVC.Get_DEMO_CONTCT", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("O_result", OracleType.Cursor).Direction = ParameterDirection.Output;
            OracleDataAdapter da = new OracleDataAdapter(cmd);
            con.Open();
            da.Fill(dt);
            con.Close();

            foreach (DataRow dr in dt.Rows)
            {
                objlist.Add(new ClsContactInfo
                {
                    FIRSTNAME = Convert.ToString(dr["FIRSTNAME"]),
                    LASTNAME = Convert.ToString(dr["LASTNAME"]),
                    EMAIL = Convert.ToString(dr["EMAIL"]),
                    PHONENUMBER = Convert.ToString(dr["PHONENUMBER"]),
                    STATUS = Convert.ToString(dr["STATUS"]),
                    ID = Convert.ToInt32(dr["ID"])

                });

            }

            return objlist;

        }

        //add method


        public void Create(ClsContactInfo objinfo)
        {
            try
            {


                string str = ConfigurationManager.ConnectionStrings["staging_ed"].ConnectionString;
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();
                OracleConnection con = new OracleConnection(str);
                OracleCommand cmd = new OracleCommand("PKG_MVC.Add_CONTCT_dEMO", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("P_FIRSTNAME", objinfo.FIRSTNAME);
                cmd.Parameters.Add("P_LASTNAME", objinfo.LASTNAME);
                cmd.Parameters.Add("P_EMAIL", objinfo.EMAIL);
                cmd.Parameters.Add("P_PHONENUMBER", objinfo.PHONENUMBER);
                cmd.Parameters.Add("P_STATUS", objinfo.STATUS);
                cmd.Parameters.Add("O_RESULT", OracleType.Cursor).Direction = ParameterDirection.Output;
                con.Open();
                 int res=cmd.ExecuteNonQuery();
                    con.Close();

            }
            catch (Exception)
            {
                
                throw;
            }
 

        }

        //end

        //update

        public bool UpdateContact(ClsContactInfo objinfo)
        {

            string str = ConfigurationManager.ConnectionStrings["staging_ed"].ConnectionString;
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            OracleConnection con = new OracleConnection(str);
            OracleCommand cmd = new OracleCommand("PKG_MVC.UPDAT_DEMO_CONCT", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("P_ID", objinfo.ID);
            cmd.Parameters.Add("P_FIRSTNAME", objinfo.FIRSTNAME);
            cmd.Parameters.Add("P_LASTNAME", objinfo.LASTNAME);
            cmd.Parameters.Add("P_EMAIL", objinfo.EMAIL);
            cmd.Parameters.Add("P_PHONENUMBER", objinfo.PHONENUMBER);
            cmd.Parameters.Add("P_STATUS", objinfo.STATUS);
            cmd.Parameters.Add("O_RESULT", OracleType.Cursor).Direction = ParameterDirection.Output;
            con.Open();
            int res = cmd.ExecuteNonQuery();
            con.Close();
            if (res >= 1)
            {
                return true;
            }
            else
            {
               return false;
            } 
        }


        //DELETE


        public bool Delete(int ID)
        {

            string str = ConfigurationManager.ConnectionStrings["staging_ed"].ConnectionString;
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            OracleConnection con = new OracleConnection(str);
            OracleCommand cmd = new OracleCommand("PKG_MVC.DeleteRec_CONTCT_Demo", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("P_ID", ID);
            cmd.Parameters.Add("O_RESULT", OracleType.Cursor).Direction = ParameterDirection.Output;
            con.Open();
            int res = cmd.ExecuteNonQuery();
            con.Close();
            if (res >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }

        }




        //END





    }
}