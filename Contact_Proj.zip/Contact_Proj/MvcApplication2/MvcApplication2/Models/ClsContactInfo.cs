﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication2.Models
{
    public class ClsContactInfo
    {


        public int ID { get; set; }
        public string FIRSTNAME { get; set;}

        public string LASTNAME { get; set;}

        public string EMAIL { get; set;}

        public string PHONENUMBER { get; set;}

        public string STATUS { get; set;}




        

    }
}