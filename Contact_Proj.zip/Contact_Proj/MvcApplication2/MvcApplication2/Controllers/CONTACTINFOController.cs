﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Configuration;
using System.Data.OracleClient;
using MvcApplication2.Models;


namespace MvcApplication2.Controllers
{
    public class CONTACTINFOController : Controller
    {
        //
        // GET: /CONTACTINFO/

        public ActionResult Index()
        {
            ClsCONTDetail objnew = new ClsCONTDetail();

            return View(objnew.GetContactList());
        }

        //add
        [HttpGet]
        public ActionResult  Create()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Create(ClsContactInfo objinfo)
        {
            if (ModelState.IsValid)
            {
                ClsCONTDetail objnew = new ClsCONTDetail();
                objnew.Create(objinfo);
                ModelState.Clear();
                ViewBag.Message = "Record  saved";

                return View();

            }
            else
            {
                ModelState.AddModelError("CONTACTINFO", "Error");
                return View();
      
            }

        }

       

        //edit


        [HttpGet]
        public ActionResult Edit(int ID)
        {
            ClsCONTDetail objnew1 = new ClsCONTDetail();

            return View(objnew1.GetContactList().Find(itemmodel => itemmodel.ID == ID));
        }



        [HttpPost]
        public ActionResult Edit(int ID, ClsContactInfo objinfo)
        {
            try
            {
                ClsCONTDetail obj = new ClsCONTDetail();
                obj.UpdateContact(objinfo);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
            
        }


        //delete
        
        public ActionResult Delete(int ID)
        {
 
            try
            {
                ClsCONTDetail ItemHandler = new ClsCONTDetail();
                if (ItemHandler.Delete(ID))
                {
                    ViewBag.AlertMsg = "Item Deleted Successfully";
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }



        }





        //end







    }
}
